const fs = require('fs')

const check = require('./validator.controller')

const userHeadr = ['name', 'Address', 'phone'];

const getDataFromJSON = () => {
    let data;
    try {
        data = JSON.parse(fs.readFileSync('./models/users.json'));
        if (!Array.isArray(data)) throw new Error('Array')
    } catch (e) {
        data = []
    }
    return data
}
const writeDataToJSON = (data) => {
    data = JSON.stringify(data)
    fs.writeFileSync('./models/users.json', data)
}

const getData = (req, type = '') => {
    let id = req.params.id
    let data = getDataFromJSON()
    let index = data.findIndex(user => user.id == id);
    let trans;
    let transIndex;
    if (type == 'trans') {
        let tranNum = req.params.tranNum
        transIndex = data[index].transactions.findIndex(tran => tran.tranNum == tranNum)
        trans = data[index].transactions[transIndex]
    }
    else ''
    return { id, data, index, trans, transIndex }
}


class User {
    static allUser(req, res) {
        let data = getDataFromJSON()
        let notExist = true
        if (data.length !== 0) notExist = false
        res.render('all', { pageTitle: "All User", notExist, data, home: true })
    }

    static addUser(req, res) {
        let errors = {}
        res.render('addUser', {
            pageTitle: 'Add New User', addUser: true,
            userData: { name: '', Address: '', phone: '', initalBalance: '' },
        })
    }

    static postAddUser(req, res) {
        let errors = {};

        if (check.checkName(req)) errors.name = check.checkName(req);
        if (check.checkAddress(req)) errors.Address = check.checkAddress(req)
        if (check.checkPhone(req)) errors.phone = check.checkPhone(req)
        if (check.checkinitalBalance(req)) errors.initalBalance = check.checkinitalBalance(req)

        if (Object.keys(errors).length != 0) {
            console.log(errors)
            res.render('addUser', { pageTitle: 'add', addUser: true, userData: req.body, errors })
        } else {
            let data = getDataFromJSON()
            let id = 5000
            if (data.length != 0) id = data[data.length - 1].id + 1
            let user = {
                id, ...req.body, transactions: [{ tranNum: Date.now(), type: 'add', value: +req.body.initalBalance }]
            }
            data.push(user)
            writeDataToJSON(data)
            res.redirect('/')
        }
    }
    static showSingle(req, res) {
        let d = getData(req)
        let noTrans = true
        if (d.index == -1) return res.redirect('/error')
        if (d.data[d.index].transactions.length != 0) noTrans = false
        let sum = 0
        d.data[d.index].transactions.forEach(v => {
            if (v.type === 'add') sum += +v.value
            else sum -= +v.value
        })
        res.render('single', { pageTitle: d.data[d.index].name, data: d.data[d.index], sum, noTrans })
    }

    static deleteUser(req, res) {
        let d = getData(req)
        d.data = d.data.filter((u, i) => i != d.index)
        writeDataToJSON(d.data)
        res.redirect('/')
    }

    static editUser(req, res) {
        let d = getData(req)
        res.render('editUser', { pageTitle: 'Edit User', data: d.data[d.index] })
    }

    static postEditUser(req, res) {
        let d = getData(req)
        let errors = {};

        if (check.checkName(req)) errors.name = check.checkName(req);
        if (check.checkAddress(req)) errors.Address = check.checkAddress(req)
        if (check.checkPhone(req)) errors.phone = check.checkPhone(req)

        if (Object.keys(errors).length != 0) {
            console.log(errors)
            res.render(`editUser`, { pageTitle: 'Edit User', data: d.data[d.index], userData: req.body, errors })
        } else {
            userHeadr.forEach(el => {
                d.data[d.index][el] = req.body[el]
            })
            writeDataToJSON(d.data)
            res.redirect(`/`)
        }


    }

    static addTransaction(req, res) {
        let d = getData(req)
        res.render('transaction', { pageTitle: 'Add transaction' ,data: d.data[d.index]})
    }

    static postAddTransaction(req, res) {
        let errors = {};
        let d = getData(req)
        var newI = 0
        let type = req.body.type
        let value = parseInt(req.body.value)
        if (type == "add"){
            newI = value + parseInt(d.data[d.index].initalBalance) 
            console.log(newI)
        } else{
            if (value > parseInt(d.data[d.index].initalBalance) ) {
                errors.type = "Less balance must be withdrawn "
            }else{
                newI =  (parseInt(d.data[d.index].initalBalance) )- value
                console.log(newI) 
            }
        }
        if (Object.keys(errors).length != 0) {
            console.log("errors")
            res.render(`transaction`, { pageTitle: '', data: d.data[d.index], userData: req.body, errors })
        } else {
            d.data[d.index].initalBalance = newI
            d.data[d.index].transactions.push({ tranNum: Date.now(), ...req.body })
            writeDataToJSON(d.data)
            res.redirect('/')

            }

    }


}


module.exports = User