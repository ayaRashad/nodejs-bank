const router = require('express').Router();
const appController = require('../controllers/app.controller')

// Home Page : 
router.get('/', appController.allUser)
router.get('/addUser', appController.addUser)
router.post('/addUser', appController.postAddUser)

router.get('/delete/:id', appController.deleteUser)

router.get('/edit/:id', appController.editUser)
router.post('/edit/:id', appController.postEditUser)

router.get('/user/:id', appController.showSingle)

 
router.get('/transaction/:id', appController.addTransaction)
router.post('/transaction/:id', appController.postAddTransaction)


router.get('*', (req, res) => res.render('error'))

module.exports = router